const express = require('express');
const Router = express.Router();

const DomainController = require('../controllers/DomainController')

//Server Routes
Router.post('/api/add-domain',DomainController.addDomain);
Router.get('/api/get-domain',DomainController.getDomain);
Router.delete('/api/delete-domain/:id', DomainController.deleteDomain);
Router.put('/api/update-domain/:id', DomainController.updateDomain);
module.exports=Router;