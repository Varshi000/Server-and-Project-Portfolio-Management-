
const Domain = require("../models/domainform");

const addDomain = async (req, res, next) => {
  console.log(req.body)
  try {
    const {
        domain,
        sub_domain,
        domain_expiry,
        auto_renewal,
        ssl_type,
        ssl_expiry
    } = req.body;

    const newDomain = new Domain({
        domain,
        sub_domain,
        domain_expiry,
        auto_renewal,
        ssl_type,
        ssl_expiry
    });

    await newDomain.save();

    res.status(201).json({ message: 'Domain added successfully' });
  } catch (error) {
    // Handle errors
    console.error(error);
    res.status(500).json({ message: 'Failed to add Domain' });
  }
};

const getDomain = async (req, res) => {
  try {
    const domains = await Domain.find();
    res.json(domains);
  } catch (err) {
    res.status(500).json({ message: err.message});
}
};
const deleteDomain = async (req, res) => {
  const _id=req.params.id
  try {
    const domain = await Domain.findByIdAndDelete({_id});
    if (!domain) {
      return res.status(404).json({ message: "Domain not found" });
    }
    res.json({ message: "Domain deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
 const updateDomain=async (req, res, next)=>{
  const _id = req.params.id
  const {
    domain,
    sub_domain,
    domain_expiry,
    auto_renewal,
    ssl_type,
    ssl_expiry} = req.body;
  let domdata;
  try{
      domdata = await Domain.findByIdAndUpdate(_id,{
        domain,
        sub_domain,
        domain_expiry,
        auto_renewal,
        ssl_type,
        ssl_expiry
      });
  }catch(err){
      return console.log(err)
  }
  if(!domdata){
      return res.status(400).json({message:"Unable to update the users."})
  }
  return res.status(200).json({domdata})
}
exports.addDomain=addDomain;
exports.getDomain = getDomain;
exports.deleteDomain = deleteDomain;
exports.updateDomain = updateDomain;




