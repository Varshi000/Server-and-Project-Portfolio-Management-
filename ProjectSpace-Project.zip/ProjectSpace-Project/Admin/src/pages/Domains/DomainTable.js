import React, { useState, useEffect } from "react";
import { MDBDataTable } from "mdbreact";
import { Row, Col, Card, CardBody, CardTitle, Button } from "reactstrap";
import { Link } from "react-router-dom";
import Breadcrumbs from "../../components/Common/Breadcrumb";
import "../Tables/datatables.scss";

const DomainTable = () => {
  const [domainData, setDomainData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editableRow, setEditableRow] = useState(null); // State to keep track of the editable row index

  useEffect(() => {
    fetchDomainData();
  }, []);

  const fetchDomainData = async () => {
    try {
      // Replace this URL with your backend API endpoint to fetch domain data
      const response = await fetch("http://localhost:5000/api/get-domain");
      const data = await response.json();
      setDomainData(data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching domain data:", error);
      setLoading(false);
    }
  };

  const handleEdit = (index) => {
    // Set the editable row index
    setEditableRow(index);
  };

  const handleSave = async (domainId) => {
    try {
      const domainToUpdate = domainData.find((domain) => domain._id === domainId);
      const response = await fetch(`http://localhost:5000/api/update-domain/${domainId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(domainToUpdate),
      });

      if (response.ok) {
        // If domain update is successful, fetch domain data again to update the table
        fetchDomainData();
      } else {
        console.error("Failed to update domain");
      }
    } catch (error) {
      console.error("Error updating domain:", error);
    }
    window.location.href="/listofdomains";
    alert("Domain is edited");
  };

  
        const handleDelete = async (domainId) => {
          try {
            const confirmed = window.confirm("Are you sure you want to delete this domain?");
            if (!confirmed) return;
        
            const response = await fetch(`http://localhost:5000/api/delete-domain/${domainId}`, {
              method: "DELETE",
            });
        
            if (response.ok) {
              // If server deletion is successful, fetch server data again to update the table
              fetchDomainData();
            } else {
              console.error("Failed to delete server");
            }
          } catch (error) {
            console.error("Error deleting server:", error);
          }
          alert("Domain is deletd");
        };
        
  const tableData = {
    columns: [
      {
        label: "Domain",
        field: "domain",
        sort: "asc",
        width: 100,
      },
      {
        label: "Sub Domain",
        field: "sub_domain",
        sort: "asc",
        width: 100,
      },
      {
        label: "Domain Expiry",
        field: "domain_expiry",
        sort: "asc",
        width: 100,
      },
      {
        label: "Auto Renewal",
        field: "auto_renewal",
        sort: "asc",
        width: 100,
      },
      {
        label: "SSL Type",
        field: "ssl_type",
        sort: "asc",
        width: 100,
      },
      {
        label: "SSL Expiry",
        field: "ssl_expiry",
        sort: "asc",
        width: 100,
      },
      {
        label: "Action",
        field: "action",
        sort: "asc",
        width: 100,
      },
    ],
    rows: domainData.map((domain, index) => ({
      domain: editableRow === index ? (
        <input
          type="text"
          value={domain.domain}
          onChange={(e) => handleInputChange(e, index, "domain")}
        />
      ) : domain.domain,
      sub_domain: editableRow === index ? (
        <input
          type="text"
          value={domain.sub_domain}
          onChange={(e) => handleInputChange(e, index, "sub_domain")}
        />
      ) : domain.sub_domain,
      domain_expiry: editableRow === index ? (
        <input
          type="url"
          value={domain.domain_expiry}
          onChange={(e) => handleInputChange(e, index, "domain_expiry")}
        />
      ) : domain.domain_expiry,
      auto_renewal: editableRow === index ? (
        <input
          type="text"
          value={domain.auto_renewal}
          onChange={(e) => handleInputChange(e, index, "auto_renewal")}
        />
      ) : domain.auto_renewal,
      ssl_type: editableRow === index ? (
        <input
          type="text"
          value={domain.ssl_type}
          onChange={(e) => handleInputChange(e, index, "ssl_type")}
        />
      ) : domain.ssl_type,
      ssl_expiry: editableRow === index ? (
        <input
          type="text"
          value={domain.ssl_expiry}
          onChange={(e) => handleInputChange(e, index, "ssl_expiry")}
        />
      ) : domain.ssl_expiry,
      action: (
        <div style={{width:100}}>
          {editableRow === index ? (
            <Button
              color="success"
              className="btn btn-success width-xs waves-effect waves-light mr-1"
              onClick={() => handleSave(domain._id)}
            >
              <i className="bx bx-check-double"></i>
            </Button>
          ) : (
            <Button
              color="primary"
              className="btn btn-primary width-xs waves-effect waves-light mr-1"
              onClick={() => handleEdit(index)}
            >
              <i className="bx bx-edit-alt"></i>
            </Button>
          )}&nbsp;
          <Button
            color="danger"
            className="btn btn-danger width-xs waves-effect waves-light"
            onClick={() => handleDelete(domain._id)}
          >
           <i className="bx bx-trash"></i>
          </Button>
        </div>
      ),
    })),
  };

  const handleInputChange = (e, index, field) => {
    const newData = [...domainData];
    newData[index][field] = e.target.value;
    setDomainData(newData);
  };

  return (
    <React.Fragment>
      <div className="page-content">
        <Breadcrumbs title="domains" breadcrumbItem="List Of domains" />
        <Row>
          <Col className="col-12">
            <Card>
              <CardBody>
                <CardTitle>
                  Default Datatable
                  <Link to="/domainform">
                    <Button
                      color="primary"
                      className="ml-1 btn btn-primary waves-effect waves-light"
                      style={{ marginLeft: 700 }}
                    >
                      Add Domain
                    </Button>
                  </Link>{" "}
                </CardTitle>
                {loading ? (
                  <p>Loading...</p>
                ) : (
                  <MDBDataTable responsive striped bordered data={tableData} noBottomColumns />
                    )}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </div>
    </React.Fragment>
  );
};

export default DomainTable;